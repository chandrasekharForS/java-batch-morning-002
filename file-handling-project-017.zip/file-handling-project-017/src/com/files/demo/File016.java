package com.files.demo;

import java.io.FileOutputStream;
import java.io.IOException;

public class File016 {

	public static void main(String[] args) {
		try(FileOutputStream ofs = new FileOutputStream("log_messages01.txt")) {
			String data = "INFO | User login successful | Username: admin";
			byte[] bytes = data.getBytes();
			
			// write byte by byte
			
			/*for(Byte b: bytes) {
				ofs.write(b);
			}*/
			
			// write byte array
			ofs.write(bytes);
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
