package com.collections.demo;

public class Student implements Comparable<Student>{
	private Long id;
	private String name;
	private String course;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(Long id, String name, String course) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", course=" + course + "]\n";
	}

	@Override
	public int compareTo(Student other) {
		
		return (int)(other.id - this.id);
	}
}
