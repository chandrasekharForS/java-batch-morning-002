package com.strings.demo;

public class Strings002 {

	public static void main(String[] args) {
		String s1 = "Hello";
		System.out.println(s1);
		
		//s1.concat(" World.");
		//String s2 = s1.concat(" World.");
		//String s2 = s1 + " World.";
		s1 = s1 + " World.";
		System.out.println(s1);
		
		String str1 = "Hello";
		String str2 = "Hello";
		
		System.out.println(str1 == str2);
		
		String str3 = new String("Hello");
		String str4 = new String("Hello");
		
		System.out.println(str3 == str4);
		
		String str5 = "There is";
		System.out.println(str5.charAt(0));
		System.out.println(str5.substring(3));
		System.out.println(str5.substring(2, 6));
		
		System.out.println("Hello".equals("hello"));
		System.out.println("Hello".equalsIgnoreCase("hello"));
		
		System.out.println("Hello".startsWith("l"));

	}

}
