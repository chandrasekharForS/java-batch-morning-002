package com.collections.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Collection {

	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<>();
		
		numbers.add(13);
		numbers.add(18);
		numbers.add(11);
		numbers.add(19);
		numbers.add(14);
		
		System.out.println(numbers);
		
		Collections.sort(numbers);
		
		System.out.println(numbers);
		
		Collections.sort(numbers, Collections.reverseOrder());
		
		System.out.println(numbers);

	}

}
