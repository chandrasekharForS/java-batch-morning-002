package com.streams.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Stream001 {

	public static void main(String[] args) {
		/*List<String> names = Arrays.asList("Anish", "Divya", "Vijay", "Anand");
		
		List<String> namesWithA = new ArrayList<>();
		
		for(String name:names) {
			if(name.startsWith("A"))
				namesWithA.add(name);
		}
		
		System.out.println(names);
		System.out.println(namesWithA);
		*/
		
		/*List<String> names = Arrays.asList("Anish", "Divya", "Vijay", "Anand");
		
		List<String> namesWithA = names.stream()
				.filter(name -> name.startsWith("A"))
				.toList();
		
		System.out.println(names);
		System.out.println(namesWithA);
		*/
		
		/*List<Integer> numbers = Arrays.asList(11, 22, 33, 44, 55);
		
		numbers.stream()
			.forEach(System.out::println);
		*/
		
		// From Array
		
		/*String[] names = {"John","David","Smith"};

		Stream<String> stream = Arrays.stream(names);

		stream.forEach(System.out::println);
		*/
		
		// Stream.of()
		
		/*Stream<Integer> stream = Stream.of(10,20,30,40);

		stream.forEach(System.out::println);
		*/
		
		// Infinite Stream
		
		/*Stream<Integer> stream = Stream.generate(() -> 100);

		stream.limit(5).forEach(System.out::println);
		*/
		
		//Stream.iterate()
		
		/*Stream.iterate(1, n -> n + 1)
		      .limit(10)
		      .forEach(System.out::println);
		*/
		
		
		
		
	}

}
