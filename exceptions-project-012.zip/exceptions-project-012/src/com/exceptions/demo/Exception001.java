package com.exceptions.demo;

public class Exception001 {

	public static void main(String[] args) {
		String name = null;
		
		System.out.println(name.length());
		
		System.out.println("End of the program");

	}
}
