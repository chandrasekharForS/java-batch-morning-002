package com.arrays.demo;

import java.util.Scanner;

public class Array002 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numbers: ");
		int nums[] = new int[5];
		
		for(int i = 0; i < nums.length; i++) {
			nums[i] = scan.nextInt();
		}
		
		System.out.println("Numbers: ");
		for(int i = 0; i < nums.length; i++) {
			System.out.println(nums[i]);
		}
		
		int max = nums[0];
		int min = nums[0];
		
		for(int i = 1; i < nums.length; i++) {
			if(nums[i] > max) {
				max = nums[i];
			}
			
			if(nums[i] < min) {
				min = nums[i];
			}
		}
		
		System.out.println("Small: " + min);
		System.out.println("Big: " + max);
		
		scan.close();

	}

}
