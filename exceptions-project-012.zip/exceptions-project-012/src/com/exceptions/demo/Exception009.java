package com.exceptions.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exception009 {

	public static void main(String[] args) {
		List<String> values = new ArrayList<>();
		values.add("Hello");
		values.add("Dear.");
		values.add("Where");
		values.add("are");
		values.add("you?");
		
		for(String value:values)
			System.out.println(value);
		
		List<String> unmodifiable_values = Collections.unmodifiableList(values);
		
		try {
			unmodifiable_values.add("Something new");
		}
		catch(UnsupportedOperationException ex) {
			System.out.println(ex.getMessage());
		}

	}

}
