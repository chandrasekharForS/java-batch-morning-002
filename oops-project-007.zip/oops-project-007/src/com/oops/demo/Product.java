package com.oops.demo;

public class Product{
	private int productId;
	private String productName;
	private double price;
	private int stock;
	
	public Product() {
		//System.out.println("Constructor is called.");
	}
	
	public Product(int productId, String productName, double price, int stock) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.stock = stock;
	}
	
	public void showProduct() {
		System.out.println("ID: " + productId);
		System.out.println("Name: " + productName);
		System.out.println("Price: " + price);
		System.out.println("Stock: " + stock);
	}
}

/*package com.oops.demo;

public class Product{
	private int productId;
	private String productName;
	private double price;
	private int stock;
	
	public void createProduct(int productId, String productName, double price, int stock) { // formal parameters
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.stock = stock;
	}
	
	public void showProduct() {
		System.out.println("ID: " + productId);
		System.out.println("Name: " + productName);
		System.out.println("Price: " + price);
		System.out.println("Stock: " + stock);
	}
}
*/
