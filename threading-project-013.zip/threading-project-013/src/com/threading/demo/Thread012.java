package com.threading.demo;

public class Thread012 {

	public static void main(String[] args) {
		
		Runnable task = new Runnable() {
			@Override
			public void run() {
				for(int i = 1; i <= 5; i++) {
					System.out.println(Thread.currentThread().getName() + ":" + i);
					
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
		};
		
		Thread t1 = new Thread(task, "First");
		Thread t2 = new Thread(task, "Second");
		Thread t3 = new Thread(task, "Third");
		
		t1.start();
		t2.start();
		t3.start();
		

	}

}
