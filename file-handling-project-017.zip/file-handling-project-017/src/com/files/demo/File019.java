package com.files.demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class File019 {

	public static void main(String[] args) {
		try(FileInputStream fis = new FileInputStream("students.ser");
			ObjectInputStream in = new ObjectInputStream(fis)) {
			
			Student s = (Student)in.readObject();
			
			System.out.println(s);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
