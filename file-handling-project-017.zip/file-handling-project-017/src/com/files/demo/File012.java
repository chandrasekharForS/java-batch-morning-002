package com.files.demo;

import java.io.File;

public class File012 {

	public static void main(String[] args) {
		File iFile = new File("messages.txt");
		File oFile = new File("imp_messages.txt");
		
		if(iFile.renameTo(oFile))
			System.out.println("Success.");
		else
			System.out.println("Failed.");

	}

}
