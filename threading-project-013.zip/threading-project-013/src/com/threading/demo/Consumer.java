package com.threading.demo;

public class Consumer extends Thread {
    SharedData data;
    public Consumer(SharedData data) { this.data = data; }

    public void run() {
        for (int i = 1; i <= 5; i++) {
            data.consume();
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    }
}

