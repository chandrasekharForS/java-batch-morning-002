package com.collections.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Collection09 {

	public static void main(String[] args) {
		ArrayList<Employee> list = new ArrayList<>();
		
        list.add(new Employee(1, "Anil", 40000));
        list.add(new Employee(2, "Sunil", 30000));
        list.add(new Employee(3, "Kiran", 50000));

        System.out.println(list);
        
        Collections.sort(list, new Comparator<Employee>() {
        	@Override
        	public int compare(Employee e1, Employee e2) {
        		return e1.salary - e2.salary;
        	}
		});
        
        System.out.println("Sort on Salary: " + list);
        
        Collections.sort(list, new Comparator<Employee>() {
        	@Override
        	public int compare(Employee e1, Employee e2) {
        		return e1.name.compareTo(e2.name);
        	}
		});
        
        System.out.println("Sort on name: " + list);


	}

}
