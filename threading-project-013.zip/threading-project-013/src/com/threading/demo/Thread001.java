package com.threading.demo;

class MyThread01 extends Thread{
	@Override
	public void run() {
		System.out.println("Thread is executing by " + Thread.currentThread().getName() + ".");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("EEEEEEEEEE");
		
	}
}

/*class MyThread02 implements Runnable {

}*/

public class Thread001 {

	public static void main(String[] args) {
		MyThread01 t1 = new MyThread01();
		t1.setName("First Thread");
		
		MyThread01 t2 = new MyThread01();
		t2.setName("Second Thread");
		
		MyThread01 t3 = new MyThread01();
		t3.setName("Third Thread");
		
		t1.start();
		t2.start();
		t3.start();
		
		
		/*t1.run();
		t2.run();
		t3.run();
		*/
	}

}
