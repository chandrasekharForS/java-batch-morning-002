package com.oops.demo;

public class Employee {
	private long id;
	private String name;
	private double salary;
	private String department;
	
	public Employee() {
		
	}
	
	public Employee(long id, String name, double salary, String department) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.department = department;
	}
	
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public String getDepartment() {
		return department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}
	
	@Override
	public String toString() {
		String out = "==============================";
		out = out + "\nID: " + id;
		out = out + "\nName: " + name;
		out = out + "\nSalary: " + salary;
		out = out + "\nDepartment: " + department;
		
		return out;
	}
	
	/*public void showEmployee() {
		System.out.println("==============================");
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("Salary: " + salary);
		System.out.println("Department: " + department);
	}*/
}
