package com.sealled.demo;

public class AutomationTester extends Tester{
    public AutomationTester(String name, double salary) {
        super(name, salary);
    }

    @Override
    public void work() {
        System.out.println(name + " is writing Selenium automation scripts.");
    }
}
