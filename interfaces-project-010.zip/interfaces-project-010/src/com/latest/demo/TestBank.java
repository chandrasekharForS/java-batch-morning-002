package com.latest.demo;

public class TestBank {

	public static void main(String[] args) {
        SBI sbi = new SBI();

        sbi.withdraw(5000);     // abstract method implemented by SBI
        sbi.deposit(10000);     // inherited default method

        Bank.bankInfo();       // static method

	}

}
