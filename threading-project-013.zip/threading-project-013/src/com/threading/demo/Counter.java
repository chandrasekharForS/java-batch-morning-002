package com.threading.demo;

public class Counter {
    private int count = 0;

    // implicit lock on 'this'
    public synchronized void increment() {
        count++;
    }

    public void incrementBlock() {
        synchronized (this) {
            count++;
        }
    }

    public int getCount() {
        return count;
    }

    public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();

        Runnable task = () -> {
            for (int i = 0; i < 1000; i++) {
                counter.increment();
                counter.incrementBlock();
            }
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        // Expected: 2 threads * 1000 iterations * 2 increments each = 4000
        System.out.println("Final count: " + counter.getCount());
    }
}

