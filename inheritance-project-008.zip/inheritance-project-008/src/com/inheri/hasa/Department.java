package com.inheri.hasa;

import java.util.Arrays;

public class Department {
	private int id;
	private String name;
	private Employee employees[] = new Employee[5];
	
	public Department(int id, String name, Employee[] employees) {
		super();
		this.id = id;
		this.name = name;
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ",\nemployees=" + Arrays.toString(employees) + "]";
	}
}
