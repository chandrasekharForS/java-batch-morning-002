package com.collections.demo;

import java.util.ArrayList;
import java.util.List;

public class Collection04 {

	public static void main(String[] args) {
		List list = new ArrayList();

		list.add(11);
		list.add(12);
		list.add(13);
		list.add(14);
		list.add(15);
		
		list.add(16);
		
		list.add("Seventeen");
		list.add(1.34);
		
		for(Object num:list)
			System.out.println(num);
		

	}

}
