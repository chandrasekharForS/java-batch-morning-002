package com.inheri.demo;

public class PersonTest {

	public static void main(String[] args) {
		/*Person p1 = new Person(101, "Anish", "Bangalore-11");
		System.out.println(p1);
		
		Employee e1 = new Employee(102, "Divya", "Bangalore-03", 900000.00);
		System.out.println(e1);
		
		Student s1 = new Student(1001, "Rajiv", "Bangalore-01", "First");
		System.out.println(s1);
	
		Customer c1 = new Customer(20001, "Ramesh", "Bangalore-05", 25500.00);
		System.out.println(c1);
		*/
		
		Employee e1 = new Employee(102, "Divya", "Bangalore-03", 900000.00);
		System.out.println(e1);
	
		
		/*Person p1 = new Person(101, "Anish", "Bangalore-11");
		System.out.println(p1);
		*/
	}

}
