package com.latest.demo;

public class CreditCard implements Payment {

}
