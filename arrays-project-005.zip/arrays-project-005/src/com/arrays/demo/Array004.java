package com.arrays.demo;

import java.util.Scanner;

public class Array004 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your friend names: ");
		String names[] = new String[3];
		
		for(int i = 0; i<names.length; i++) {
			names[i] = scanner.next();
			
		}
		
		System.out.println("Enter a name to find: ");
		String name = scanner.next();
		
		boolean isFound = false;
		
		for(int i = 0; i < names.length; i++) {
			//if(name == names[i]) {
			if(name.equals(names[i]) == true) {
				System.out.println("Found.");
				isFound = true;
				break;
			}
		}
		
		if(isFound == false) {
			System.out.println("Not found.");
		}
		
		scanner.close();

	}

}
