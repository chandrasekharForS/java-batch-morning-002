package com.oops.demo;

public class ProductTest {

	public static void main(String[] args) {
		/*Product p1 = new Product();
		
		p1.productId = 101;
		p1.productName = "T.V";
		p1.price = 98750.00;
		p1.stock = 2;
		
		System.out.println("Product 1:");
		System.out.println("ID: " + p1.productId);
		System.out.println("Name: " + p1.productName);
		System.out.println("Price: " + p1.price);
		System.out.println("Stock: " + p1.stock);
		
		Product p2 = new Product();
		
		p2.productId = 102;
		p2.productName = "Mobile";
		p2.price = 25000.00;
		p2.stock = 20;
		
		System.out.println("Product 2:");
		System.out.println("ID: " + p2.productId);
		System.out.println("Name: " + p2.productName);
		System.out.println("Price: " + p2.price);
		System.out.println("Stock: " + p2.stock);
		*/
		
		Product p1 = new Product();
		p1.createProduct(101, "T.V", 98750.00, 2); // actual parameters
		
		System.out.println("Product 1:");
		p1.showProduct();
		
		Product p2 = new Product();
		p2.createProduct(102, "Mobile", 25000.00, 20);
		
		System.out.println("\nProduct 2:");
		p2.showProduct();
		

	}

}
