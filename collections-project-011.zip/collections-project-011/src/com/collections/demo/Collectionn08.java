package com.collections.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Collectionn08 {

	public static void main(String[] args) {
		/*List<Integer> numbers = new ArrayList<>();
		numbers.add(15);
		numbers.add(12);
		numbers.add(18);
		numbers.add(5);
		numbers.add(16);

		System.out.println(numbers);
		
		Collections.sort(numbers);
		
		System.out.println(numbers);
		*/
		
		/*List<String> names = new ArrayList<>();
		names.add("Rajesh");
		names.add("Ramesh");
		names.add("Suresh");
		names.add("Anish");
		
		System.out.println(names);
		
		Collections.sort(names);
		
		System.out.println(names);
		*/
		
		Student s1 = new Student(103L, "Rajesh", "Java");
		Student s2 = new Student(102L, "Anish", "Python");
		Student s3 = new Student(101L, "Suresh", "Java");
		Student s4 = new Student(104L, "Mahesh", "ML");
		Student s5 = new Student(105L, "Divya", "Python");
		
		List<Student> students = new ArrayList<Student> ();
		students.add(s1);
		students.add(s2);
		students.add(s3);
		students.add(s4);
		students.add(s5);
		
		System.out.println(students);
		
		Collections.sort(students);
		
		System.out.println(students);
		
		Collections.sort(students, Collections.reverseOrder());
		
		System.out.println(students);

	}

}
