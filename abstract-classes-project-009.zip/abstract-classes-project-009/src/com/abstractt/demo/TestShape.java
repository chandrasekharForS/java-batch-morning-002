package com.abstractt.demo;

import java.util.Scanner;

public class TestShape {

	public static void main(String[] args) {
		Shape shapes[] = new Shape[5];
		
		Scanner scan = new Scanner(System.in);
		
		for(int i = 0; i < shapes.length; i++) {
			System.out.println("Enter the object to find area(c/r/s): ");
			char ch = scan.next().charAt(0);
			
			if(ch == 'c') {
				System.out.println("Ente the radius: ");
				double radius = scan.nextDouble();
				
				shapes[i] = new Circle(radius);
			}
			else if(ch == 'r') {
				System.out.println("Ente the length: ");
				double length = scan.nextDouble();
				
				System.out.println("Ente the width: ");
				double width = scan.nextDouble();
				
				shapes[i] = new Rectangle(length, width);
			}
			else if (ch == 's') {
				System.out.println("Ente the side: ");
				double side = scan.nextDouble();
				
				shapes[i] = new Square(side);
			}
			else {
				System.out.println("You have selected wrong choice.");
			}
		}
		
		for(int i = 0; i < shapes.length; i++) {
			System.out.println("==============================");
			System.out.println("Area : " + shapes[i].findArea());
			System.out.println("Circumference: " + shapes[i].findCircumference());
		}
		
		
		
		scan.close();
		
		
		
		// Shape s1 = new Shape();
		
		/*Shape s = null;
		
		//1. create circle object
		s = new Circle(1);
		
		System.out.println("Area of a circle: " + s.findArea());
		System.out.println("Circumference of a circle: " + s.findCircumference());
		
		//2. create rectangle object
		s = new Rectangle(1, 2);
		
		System.out.println("\n\nArea of a rectangle: " + s.findArea());
		System.out.println("Circumference of a rectangle: " + s.findCircumference());
		
		
		//3. create square object
		s = new Square(1);
		
		System.out.println("\n\nArea of a square: " + s.findArea());
		System.out.println("Circumference of a square: " + s.findCircumference());
		
		// 4. create traingle object(which is not possible)
		
		// s = new Traingle();
		*/
	}

}
