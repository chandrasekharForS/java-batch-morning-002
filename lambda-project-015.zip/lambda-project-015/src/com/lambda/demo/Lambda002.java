package com.lambda.demo;

public class Lambda002 {

	public static void main(String[] args) {
		/*Runnable r = new Runnable() {
			@Override
			public void run() {
				System.out.println("Hello from lambda.");
				
			}	
		};
		
		r.run();
		*/
				
		Runnable r = () -> System.out.println("Hello from lambda.");
		r.run();
	}

}
