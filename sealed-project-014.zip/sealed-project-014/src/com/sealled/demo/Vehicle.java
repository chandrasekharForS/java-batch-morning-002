package com.sealled.demo;

public sealed class Vehicle permits Car, Bike {

}
