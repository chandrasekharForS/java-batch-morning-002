package com.strings.demo;

public class Strings003 {

	public static void main(String[] args) {
		/*String s = "Java Programming";
		//System.out.println(s.length());
		int count = 0;
		for(int i = 0; i < s.length(); i++) {
			count = count + 1;
		}
		
		System.out.println(count);
		
		String str = "Java";
		
		System.out.println(str);
		
		String cStr = str.replace("Java", "Python");
		
		System.out.println(cStr);
		*/
		
		String s = "hello";
		String r = "";
		
		for(int i = s.length()-1; i >=0 ; i--) {
			r = r + s.charAt(i);
		}
		
		System.out.println(r);
		

	}

}
