package com.arrays.demo;

import java.util.Scanner;

public class Array005 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numbers: ");
		int nums[] = new int[5];
		
		for(int i = 0; i < nums.length; i++) {
			nums[i] = scan.nextInt();
		}
		
		System.out.println("Before sorting: ");
		for(int i = 0; i < nums.length; i++) {
			System.out.println(nums[i]);
		}
		
		// sorting logic
		for(int i = 0; i < nums.length; i++) {
			for(int j = i; j < nums.length; j++) {
				if(nums[i] > nums[j]) {
					int t = nums[i];
					nums[i] = nums[j];	
					nums[j] = t;
				}
			}
		}
		
		System.out.println("After sorting: ");
		for(int i = 0; i < nums.length; i++) {
			System.out.println(nums[i]);
		}
		
		scan.close();

	}

}
