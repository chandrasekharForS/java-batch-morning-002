package com.types.demo;

public class Dog extends Animal {
	@Override
	public void eat() { // we have overridden the method eat
		super.eat();
		System.out.println("Dog is eating.");
	}
	
	public void bark() {
		System.out.println("Dog is barking.");
	}
}
