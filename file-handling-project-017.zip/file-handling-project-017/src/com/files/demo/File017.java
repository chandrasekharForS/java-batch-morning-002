package com.files.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class File017 {

	public static void main(String[] args) {
		try(FileInputStream fis = new FileInputStream("image001.png");
			FileOutputStream fos = new FileOutputStream("image001_copy.png")) {
			
			byte[] buffer = new byte[1024];
			int bytesRead;
			
			while((bytesRead = fis.read(buffer)) != -1) {
				fos.write(buffer, 0, bytesRead);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
