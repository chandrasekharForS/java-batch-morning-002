package com.staticclass.demo;

public class BankAccountTest {

	public static void main(String[] args) {
		BankAccount account1 = new BankAccount(101, "Ravi", 50000);
        BankAccount account2 = new BankAccount(102, "Anita", 75000);

        System.out.println("Before Updating Interest Rate");
        System.out.println(account1);
        System.out.println(account2);

        BankAccount.updateInterestRate(7.0);
        
        System.out.println("After Updating Interest Rate");
        System.out.println(account1);
        System.out.println(account2);
        

	}

}
