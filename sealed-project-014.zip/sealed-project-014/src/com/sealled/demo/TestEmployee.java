package com.sealled.demo;

public class TestEmployee {
	public static void main(String[] args) {
        
		Employee e1 = new Developer("Ravi", 70000);
        
		Employee e2 = new Tester("Priya", 50000);
        
		Employee e3 = new AutomationTester("Kiran", 65000);
        
		Employee e4 = new ProjectManager("Anil", 90000);
		
		Employee e5 = new Manager("Rajesh", 1000000);

        Employee employees[] = {e1, e2, e3, e4, e5};

        for(Employee emp : employees) {
            emp.displayEmployee();
            emp.work();
            System.out.println("------------------------");
        }
    }
}
