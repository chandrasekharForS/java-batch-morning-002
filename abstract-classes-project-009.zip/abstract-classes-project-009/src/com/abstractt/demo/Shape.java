package com.abstractt.demo;

public abstract class Shape {
	public abstract double findArea();
	public abstract double findCircumference();
	
}
