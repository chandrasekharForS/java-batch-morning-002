package com.collections.demo;

import java.util.ArrayList;

public class Collection02 {

	public static void main(String[] args) {

		ArrayList list = new ArrayList();
		
		list.add(11);
		list.add(12);
		list.add(13);
		list.add(14);
		list.add(15);
		
		list.add(16);
		
		//list.add("Seventeen");
		//list.add(1.34);
		
		int sum = 0;
		
		for(Object num:list) {
			sum = sum + (int)num;
		}
		
		System.out.println("Sum: " + sum);

	}

}
