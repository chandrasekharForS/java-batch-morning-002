package com.abstractt.demo;

public class Square extends Shape {
	private double side;

	public Square(double side) {
		super();
		this.side = side;
	}
	
	@Override
	public double findArea() {
		return side * side;
	}
	
	@Override
	public double findCircumference() {
		return 4 * side;
	}

}
