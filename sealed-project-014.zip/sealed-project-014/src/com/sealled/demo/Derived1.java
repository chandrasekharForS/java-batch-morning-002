package com.sealled.demo;

public class Derived1 extends Base {

}
