package com.latest.demo;

public class TestPayment {

	public static void main(String[] args) {
		Payment payment = new CreditCard();
		payment.makePayment();

	}

}
