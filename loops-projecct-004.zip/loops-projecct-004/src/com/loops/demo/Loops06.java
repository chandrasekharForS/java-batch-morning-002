package com.loops.demo;

import java.util.Scanner;

public class Loops06 {

	public static void main(String[] args) {
		//s = 1^1 + 2^2 + 3^3 + 4^4 +......+ n
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the number: ");
		int num = scan.nextInt();
		
		int sum = 0;
		
		for(int i = 1; i <= num; i++) {
			int power = 1;
			for(int j = 1; j <= i; j++) {
				power = power * i;
			}
			
			sum = sum + power;
		}
		
		System.out.println("Result: " + sum);

	}

}
