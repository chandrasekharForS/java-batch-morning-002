package com.threading.demo;

public class Restaurant {
	private boolean orderPlaced = false;
	private boolean foodReady = false;
	
	public synchronized void placeOrder() {
		System.out.println("Customer order placed.");
		orderPlaced = true;
		notifyAll();
	}
	
	public synchronized void prepareFood() {
        try {
            while (!orderPlaced) {
                System.out.println("Chef : Waiting for customer order...");
                wait();                    // WAITING state
            }

            System.out.println("Chef : Preparing Food...");
            Thread.sleep(4000);            // TIMED_WAITING
            
            foodReady = true;

            System.out.println("Chef : Food Ready.");
            
            notifyAll();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
	
	// Delivery Boy waits until food is ready
    public synchronized void deliverFood() {

        try {

            while (!foodReady) {
                System.out.println("Delivery Boy : Waiting for food...");
                wait();                      // WAITING
            }

            System.out.println("Delivery Boy : Picking up food...");

            Thread.sleep(3000);             // TIMED_WAITING

            System.out.println("Delivery Boy : Food Delivered.");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

