package com.classes.publicc;

public class Derived extends Base {
	public void Test() {
		// privA = 1;
		protA = 2; // protected is public in derived class
		pubA=3;
		defA = 4;

	}
}
