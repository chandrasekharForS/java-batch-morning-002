package com.files.demo;

import java.io.FileInputStream;
import java.io.IOException;

public class File014 {

	public static void main(String[] args) {
		try(FileInputStream fis = new FileInputStream("products.txt")){
			int data;
		
			while((data = fis.read())!= -1) {
				System.out.print((char)data);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		

	}

}
