package com.oops.demo;

public class EmployeeTest {

	public static void main(String[] args) {
		Employee e1 = new Employee(101, "Anish", 900000.00, "IT");
		
		System.out.println(e1);
		
		//System.out.println(e1.toString());
		
		//e1 = new Employee(101, "Anish", 950000.00, "IT");
		//e1.salary = 950000.00;
		
		e1.setName("Anish Kumar");
		e1.setSalary(950000.00);
		
		//e1.showEmployee();
		
		System.out.println(e1.getName() + " salary is changed to " + e1.getSalary());

	}

}
