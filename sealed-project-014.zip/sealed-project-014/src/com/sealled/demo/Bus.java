package com.sealled.demo;

/*public final class Bus extends Vehicle {

}*/

