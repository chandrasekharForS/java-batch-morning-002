package com.arrays.demo;

import java.util.Scanner;

public class Array001 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numbers: ");
		int nums[] = new int[5];
		
		for(int i = 0; i < nums.length; i++) {
			nums[i] = scan.nextInt();
		}
		
		System.out.println("Numbers: ");
		for(int i = 0; i < nums.length; i++) {
			System.out.println(nums[i]);
		}
		
		int total = 0;
		double avg = 0.0;
		
		for(int i = 0; i < nums.length; i++) {
			total = total + nums[i];
		}
		
		avg = (double)total/nums.length;
		
		System.out.println("Sum: " + total);
		System.out.println("Average: " + avg);
		
		
		scan.close();

	}

}
