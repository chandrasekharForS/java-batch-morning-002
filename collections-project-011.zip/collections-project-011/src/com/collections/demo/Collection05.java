package com.collections.demo;

import java.util.ArrayList;
import java.util.List;

public class Collection05 {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();

		list.add(11);
		list.add(12);
		list.add(13);
		list.add(14);
		list.add(15);
		
		list.add(16);
		
		
		for(Integer num:list)
			System.out.println(num);
		

	}

}
