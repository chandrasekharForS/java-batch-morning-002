package com.exceptions.demo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exception003 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		try {
			System.out.println("Enter number1: ");
			int n1 = scanner.nextInt();
			
			System.out.println("Enter number2: ");
			int n2 = scanner.nextInt();
	
			System.out.println("Sum: " + (n1 + n2));
			System.out.println("Difference: " + (n1 - n2));
			System.out.println("Product: " + n1 * n2);
			System.out.println("Division: " + n1 / n2);
		}
		catch(ArithmeticException ex) {
			System.out.println(ex.getMessage());
		}
		catch(InputMismatchException ex) {	
			System.out.println("You must give a number as input."); 
		}
		
		scanner.close();

	}

}
