package com.exceptions.demo;

public class Exception005 {

	public static void main(String[] args) {
		Object obj = new Integer(100);
		
		try {
		String str = (String)obj;
		
		System.out.println(str);
		}
		catch(ClassCastException ex) {
			System.out.println(ex.getMessage());
		}
	}

}
