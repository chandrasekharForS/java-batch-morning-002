package com.latest.demo;

public interface Payment {
	default void makePayment() {
		validate();
        System.out.println("Payment completed");
    }
	
	private void validate() {
		System.out.println("Validated...");
	}

}
