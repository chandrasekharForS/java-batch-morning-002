package com.abstractt.demo;

public class TestCalculator {

	public static void main(String[] args) {
		Calculator c1 = new Calculator();
		System.out.println("Sum: " + c1.add(20, 10));
		
		// System.out.println("Sum: " + c1.add(c1.add(30, 20), 10));
		
		System.out.println("Sum: " + c1.add(30, 20, 10));
		
		System.out.println("Sum: " + c1.add(30.3, 20.2, 10.1));
		

	}

}
