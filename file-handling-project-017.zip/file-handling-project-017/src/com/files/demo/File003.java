package com.files.demo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class File003 {

	public static void main(String[] args) {
		
		try(FileReader reader = new FileReader("friends.txt")) {
			int ch;
			
			while((ch = reader.read()) != -1) {
				System.out.print((char)ch);
			}
		}
		catch(FileNotFoundException ex) {
			ex.printStackTrace();
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
	}

}
