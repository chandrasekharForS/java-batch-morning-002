package com.staticclass.demo;

public class BankAccount {
    // ---------------- Static Data Member ----------------
	private static double interestRate = 6.5;
	
    // ---------------- Instance Data Members ----------------
    private int accountNumber;
    private String customerName;
    private double balance;
   
    
    // ---------------- Constructor ----------------
    public BankAccount(int accountNumber, String customerName, double balance) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = balance;
    }
    
    
    public static void updateInterestRate(double newRate) {
    	interestRate = newRate;
    }

 // ---------------- Getter Methods ----------------
    public int getAccountNumber() {
        return accountNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getBalance() {
        return balance;
    }

    public static double getInterestRate() {
        return interestRate;
    }

    // ---------------- Setter Methods ----------------
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    // ---------------- toString() Method ----------------
    @Override
    public String toString() {
        return "BankAccount{" +
                "accountNumber=" + accountNumber +
                ", customerName='" + customerName + '\'' +
                ", balance=" + balance +
                ", interestRate=" + interestRate +
                "%}";
    }
}
