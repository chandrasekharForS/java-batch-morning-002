package com.strings.demo;

public class Strings006 {

	public static void main(String[] args) {
		/*String str = "Hello";
		StringBuffer rev = new StringBuffer();
		
		for(int i = str.length()-1; i >= 0; i--) {
			rev.append(str.charAt(i));
		}

		System.out.println("Reverse: " + rev);
		*/
		
		StringBuffer str = new StringBuffer("Hello");
		System.out.println(str);
		System.out.println(str.reverse());
		
	}
}
