package com.sealled.demo;

public non-sealed class Tester extends Employee{

	public Tester(String name, double salary) {
		super(name, salary);
	}

	@Override
	public void work() {
		System.out.println(name + " is developing Java applications.");
	}

}
