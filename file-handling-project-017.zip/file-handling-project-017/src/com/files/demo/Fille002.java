package com.files.demo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Fille002 {

	public static void main(String[] args) {
		FileReader reader = null;
		
		try {
			reader = new FileReader("friiends.txt");
			//System.out.println((char)reader.read());
			
			int ch;
			
			while((ch = reader.read()) != -1) {
				System.out.print((char)ch);
			}
		}
		catch(FileNotFoundException ex) {
			ex.printStackTrace();
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
		finally {
			try {
				if(reader != null)
					reader.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		

	}

}
