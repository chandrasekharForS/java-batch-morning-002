package com.threading.demo;

public class Producer extends Thread {
    SharedData data;
    public Producer(SharedData data) { this.data = data; }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            data.produce(i);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    }
}

