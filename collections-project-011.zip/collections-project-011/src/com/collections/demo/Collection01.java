package com.collections.demo;

import java.util.ArrayList;

public class Collection01 {

	public static void main(String[] args) {
		int nums[] = new int[5];
		nums[0] = 11;
		nums[1] = 12;
		nums[2] = 13;
		nums[3] = 14;
		nums[4] = 15;
		
		// nums[5] = 16;
		
		System.out.println(nums);
		
		for(int i = 0; i < nums.length; i++)
			System.out.println(nums[i]);

		for(int num:nums)
			System.out.println(num);
		
		ArrayList list = new ArrayList();
		//list[0] = 11;
		
		list.add(11);
		list.add(12);
		list.add(13);
		list.add(14);
		list.add(15);
		
		list.add(16);
		
		list.add("Seventeen");
		list.add(1.34);
		list.add(new Product(101L, "Pen", 15.50));
		
		System.out.println(list);
		for(Object num:list)
			System.out.println(num);
		
		for(int i = 0; i < list.size(); i++)
			//System.out.println(list[i]);
			System.out.println(list.get(i));
		
		
		
		
		
				

	}

}
