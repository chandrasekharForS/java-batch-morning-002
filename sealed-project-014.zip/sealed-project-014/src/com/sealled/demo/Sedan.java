package com.sealled.demo;

public final class Sedan extends Car {

}
