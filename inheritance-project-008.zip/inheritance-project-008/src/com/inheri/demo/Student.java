package com.inheri.demo;

public class Student extends Person {
	private String grade;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int id, String name, String address, String grade) {
		super(id, name, address);
		
		this.grade = grade;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return super.toString() + ", grade=" + grade;
	}
}
