package com.decisions.demo;

import java.util.Scanner;

public class If06 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a character: ");
		char ch = scan.next().charAt(0);
		//if((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) {
		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
			if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' 
					|| ch == 'u' || ch == 'A' || ch == 'E' || 
					ch == 'I' || ch == 'O' || ch == 'U') {
				System.out.println("Vowel.");
			}
			else {
				System.out.println("Consonant.");
			}
		}
		else {
			System.out.println("Invalid input.");
		}

	}

}
