package com.threading.demo;

public class Thread013 {

    public static void main(String[] args) {

        Thread t1 = new Thread("Thread1") {
            @Override
            public void run() {
                for (int i = 1; i <= 5; i++) {
                    System.out.println(getName() + ": " + i);

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        Thread t2 = new Thread("Thread2") {
            @Override
            public void run() {
                for (int i = 1; i <= 5; i++) {
                    System.out.println(getName() + ": " + i);

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        t1.start();
        t2.start();
    }
}

