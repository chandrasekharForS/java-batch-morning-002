package com.threading.demo;

class MyThread009 extends Thread {
    public MyThread009(String name) {
        super(name);
    }

    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(getName() + " (Priority: " + getPriority() + ") - Count: " + i);
        }
    }
}


public class Thread009 {
    public static void main(String[] args) {
        MyThread009 t1 = new MyThread009("Low Priority Thread");
        MyThread009 t2 = new MyThread009("Normal Priority Thread");
        MyThread009 t3 = new MyThread009("High Priority Thread");

        // Set priorities
        t1.setPriority(Thread.MIN_PRIORITY);   // 1
        t2.setPriority(Thread.NORM_PRIORITY);  // 5
        t3.setPriority(Thread.MAX_PRIORITY);   // 10

        // Start threads
        t1.start();
        t2.start();
        t3.start();
    }
}

