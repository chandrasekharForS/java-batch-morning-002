package com.classes.other;

import com.classes.publicc.Base;

public class TestBase {

	public static void main(String[] args) {
		Base b1 = new Base();
		
		// b1.privA = 11;
		
		//b1.protA = 22; // protected member becomes private outside the package.
		
		b1.pubA = 33;
		
		//b1.defA = 44; // default members are just like public within the same package, in other package its like private
		
		
		

	}

}
