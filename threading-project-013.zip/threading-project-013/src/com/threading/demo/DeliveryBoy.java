package com.threading.demo;

public class DeliveryBoy extends Thread {

    private Restaurant restaurant;

    public DeliveryBoy(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    @Override
    public void run() {
        restaurant.deliverFood();
    }
}

