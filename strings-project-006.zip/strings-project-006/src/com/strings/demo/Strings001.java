package com.strings.demo;

import java.util.Scanner;

public class Strings001 {

	public static void main(String[] args) {
		/*String s1 = "Hello";
		String s2 = new String("World");
		
		Scanner scan = new Scanner(System.in);
		*/
		
		String s1 = "Hello";
		String s2 = "Hello";
		
		int n1 = 10;
		int n2 = 10;
		
		
		String str1 = "Hello"; // String letteral
		String str2 = new String("Hello"); // String object
		
		String str3 = "Hi";
		String str4 = new String("Hello");
		
		
		
	}

}
