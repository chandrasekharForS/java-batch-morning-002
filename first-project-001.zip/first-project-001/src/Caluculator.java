
public class Caluculator {
	public static void main(String[] args) {
		System.out.println("Welcome to you");
		System.out.println("Where are you from?");
	}
}
