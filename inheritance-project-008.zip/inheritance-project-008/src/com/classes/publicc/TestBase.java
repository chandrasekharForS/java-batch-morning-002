package com.classes.publicc;

public class TestBase {

	public static void main(String[] args) {
		Base b1 = new Base();
		
		//b1.privA = 10; // private members can't be accessed
		
		b1.protA = 20; // protected members can be accessed in the derived class and for the same class inside the same package
		
		b1.pubA = 30; // public members can be accessed everywhere.
		
		b1.defA = 40; // default members are just like public within the same package
	}
}
