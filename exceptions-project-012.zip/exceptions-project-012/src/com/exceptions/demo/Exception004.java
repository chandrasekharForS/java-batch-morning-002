package com.exceptions.demo;

public class Exception004 {

	public static void main(String[] args) {
		int nums[] = {1, 2, 3, 4};
		try {
			System.out.println(nums[4]);
		}
		catch(IndexOutOfBoundsException ex) {
			System.out.println(ex.getMessage());
		}
		System.out.println("End of the program.");
	}

}
