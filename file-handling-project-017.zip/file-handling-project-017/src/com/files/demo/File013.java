package com.files.demo;

import java.io.File;

public class File013 {

	public static void main(String[] args) {
		File file = new File("marks.txt");
		
		if(file.delete())
			System.out.println("Deleted.");
		else
			System.out.println("Not deleted.");

	}

}
