package com.latest.demo;

public class MotorCycle implements Vehicle {
	/*public void start() {
		System.out.println("Vehicle is starting..");
	}*/
}
