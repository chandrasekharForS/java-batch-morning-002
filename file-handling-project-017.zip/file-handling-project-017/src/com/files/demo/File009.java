package com.files.demo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class File009 {

	public static void main(String[] args) {
		try(BufferedWriter writer = new BufferedWriter(new FileWriter("products.txt"))) {
			writer.write("Mobile");
			writer.newLine();
			
			writer.write("T.V");
			writer.newLine();
			
			writer.write("Fridge");
			writer.newLine();
			
			writer.write("Laptop");
			writer.newLine();
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
