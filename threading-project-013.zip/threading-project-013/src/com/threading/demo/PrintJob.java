package com.threading.demo;


public class PrintJob implements Runnable {
    private String name;

    public PrintJob(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println(name + " started by " + Thread.currentThread().getName());
        try {
            Thread.sleep(1000); // Simulate time-consuming task
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(name + " completed by " + Thread.currentThread().getName());
    }
}

