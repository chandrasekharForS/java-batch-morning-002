
public class Square {
	public static void main(String[] ars) {
		short n1 = 12;
		
		short r = (short)(n1 * n1);
		
		System.out.println("Square of the number:" + r);
	}
}
