package com.streams.demo;

import java.util.List;
import java.util.stream.IntStream;

public class Stream004 {

	public static void main(String[] args) {
		/*List<Integer> list = IntStream.rangeClosed(1,100)
                .boxed()
                .toList();

		list.stream()
			.forEach(System.out::println);
		*/
		
		/*List<Integer> list = IntStream.rangeClosed(1,10)
                .boxed()
                .toList();

		list.parallelStream()
		.forEach(System.out::println);
		*/
		
		List<Integer> list = IntStream.rangeClosed(1,10)
                .boxed()
                .toList();

		list.parallelStream()
		.forEachOrdered(System.out::println);
		
		

	}

}
