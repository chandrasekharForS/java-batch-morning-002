package com.strings.demo;

public class Strinngs007 {

	public static void main(String[] args) {
		String str = "Hello";
		
		//System.out.println(str.length());
		/*int length = 0;
		
		for(int i = 0; i < str.length(); i++) {
			length += 1;
		}
		
		System.out.println(length);
		*/
		
		int length = 0;
		for(char ch : str.toCharArray()) {
			length = length + 1;
		}
		System.out.println(length);
		
	}

}
