package com.files.demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class File004 {

	public static void main(String[] args) {
		try (BufferedReader reader = new BufferedReader(new FileReader("friends.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


	}

}
