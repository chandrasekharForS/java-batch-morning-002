package com.lambda.demo;

import java.util.function.BiFunction;
import java.util.function.Function;

@FunctionalInterface
interface Squarer{
	int square(int x);
}
public class Lambda004 {

	public static void main(String[] args) {
		/*Squarer sq = (x) -> x * x;
		System.out.println(sq.square(4));
		*/
		
		Function<Integer, Integer>  square = (x) -> x * x;
		int r = square.apply(4);
		
		System.out.println(r);
		
		Function<Integer, String> message = (x) -> "Your age is: " + x;
		System.out.println(message.apply(24));
		
		BiFunction<Integer, Integer, Integer> product = (n1, n2) -> n1 * n2;
		System.out.println("Product: " + product.apply(5, 7));
		
		BiFunction<String, String, String> concat = (fn, ln) -> fn + " " + ln;
		System.out.println("Fullname: " + concat.apply("Rajesh", "Menon"));
		
		
		
		
	}

}
