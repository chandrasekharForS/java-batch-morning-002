package com.sealled.demo;

public class Derived2 extends Base {

}
