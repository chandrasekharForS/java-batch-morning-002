package com.latest.demo;

public class ElectronicCalculator implements Calculator {

}
