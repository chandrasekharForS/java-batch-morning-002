package com.types.demo;

public class Animal {
	public void eat() {
		System.out.println("Animal is eating.");
	}
}
