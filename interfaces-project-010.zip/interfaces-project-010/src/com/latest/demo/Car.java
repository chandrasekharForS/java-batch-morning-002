package com.latest.demo;

public class Car implements Vehicle {
	/*public void start() {
		System.out.println("Vehicle is starting..");
	}*/
	
	@Override
	public void start() {
		System.out.println("Car is starting...");
	}
}
