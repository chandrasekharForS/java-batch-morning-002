package com.files.demo;

import java.io.FileWriter;
import java.io.IOException;

public class File008 {

	public static void main(String[] args) {
		try(FileWriter writer = new FileWriter("customers.txt")){
			writer.write("Anish\n");
			writer.write("Mahesh\n");
			writer.write("Vidhya\n");
			writer.flush();
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
