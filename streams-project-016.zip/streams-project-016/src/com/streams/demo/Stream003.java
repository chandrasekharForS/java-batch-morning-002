package com.streams.demo;

import java.util.List;
import java.util.Optional;

public class Stream003 {

	public static void main(String[] args) {
		// findFirst()
		/*Optional<String> first =
			    List.of("Rajesh","Anish","Divya")
			        .stream()
			        .findFirst();

			System.out.println(first.get());
		*/
		
		/*Optional<String> name = Optional.of("Rajesh");
		System.out.println(name.get());
		*/
		
		/*String name = null;
		Optional<String> result = Optional.ofNullable(name);
		
		System.out.println(result.get());
		*/
		
		// anyMatch()
		/*boolean result = List.of(10,20,30)
		    .stream()
		    .anyMatch(n -> n > 25);

		System.out.println(result);
		*/
		
		//allMatch()
		/*boolean result = List.of(10,20,30)
		    .stream()
		    .allMatch(n -> n > 5);

		System.out.println(result);
		*/
		
		// noneMatch()
		/*boolean result = List.of(10,20,30)
				    .stream()
				    .noneMatch(n -> n < 0);

				System.out.println(result);
		*/
		
		// reduce
		/*int sum = List.of(10,20,30,40)
				    .stream()
				    .reduce(0, Integer::sum);

		System.out.println(sum);
		*/
		
	
	}

}
