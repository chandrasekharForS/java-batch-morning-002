package com.classes.publicc;

public class Base {
	private int privA;
	protected int protA;
	public int pubA;
	int defA;
}
