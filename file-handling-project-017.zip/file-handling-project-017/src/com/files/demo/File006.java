package com.files.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class File006 {

	public static void main(String[] args) {
		File file = new File("friends.txt");
		Scanner scanner = null;
		try {
			scanner = new Scanner(file);
			while(scanner.hasNextLine()) {
				String name = scanner.nextLine();
				System.out.println(name);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			scanner.close();
		}

	}

}
