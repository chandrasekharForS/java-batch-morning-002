package com.lambda.demo;

import java.util.Arrays;
import java.util.List;

public class Lambda001 {

	public static void main(String[] args) {
		//System.out.println(square(2));
		
		// int r = (x) -> x * x;
		
		List<String> names = Arrays.asList("John", "Alice","Bob");
		
		/*for(String name:names) {
			if(name.startsWith("A"))
				System.out.println(name);
		}
		*/
		
		names.stream()
			.filter(name -> name.startsWith("A".toUpperCase()))
			.forEach(name -> System.out.println(name));
		
		
		/*List<String> list = Arrays.asList("Banana", "Apple", "Mango");
		list.sort((a,b) -> b.compareTo(a));
		System.out.println(list);
		*/
	}
	
	public static int square(int x) {
		return x * x;
	}

}
