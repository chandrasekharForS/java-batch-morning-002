package com.files.demo;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class File018 {

	public static void main(String[] args) {
		Student s1 = new Student(101, "Anish", 99, "Bangalore-13");
		
		try(FileOutputStream fos = new FileOutputStream("students.ser");
			ObjectOutputStream out = new ObjectOutputStream(fos)) {
			
			out.writeObject(s1);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
	}

}
