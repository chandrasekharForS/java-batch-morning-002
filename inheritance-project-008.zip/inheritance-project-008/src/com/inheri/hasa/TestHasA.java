package com.inheri.hasa;

public class TestHasA {

	public static void main(String[] args) {
		Employee e1 = new Employee(101, "Anish", 900000.00);
		Employee e2 = new Employee(102, "Divya", 900000.00);
		Employee e3 = new Employee(103, "Vidhya", 900000.00);
		Employee e4 = new Employee(104, "Rajesh", 900000.00);
		Employee e5 = new Employee(105, "Mahesh", 900000.00);
		
		/*Employee employees[] = new Employee[5];
		employees[0] = e1;
		employees[1] = e2;
		employees[2] = e3;
		employees[3] = e4;
		employees[4] = e5;
		*/
		
		//int nums[] = new int[] {1, 2, 3, 4, 5};
		
		//int nums[] = {1, 2, 3, 4, 5};
		
		
		//Employee employees[] = new Employee[] {e1, e2, e3, e4,  e5};
		
		Employee employees[] = {e1, e2, e3, e4,  e5};
		
		
		Department d1 =  new Department(1, "Production", employees);
		
		System.out.println(d1);

	}

}
