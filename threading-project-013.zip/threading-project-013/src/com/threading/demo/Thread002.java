package com.threading.demo;

class MyThread implements Runnable{

	@Override
	public void run() {
		System.out.println("Thread is executing by " + Thread.currentThread().getName() + ".");
	}
	
}
public class Thread002 {

	public static void main(String[] args) {
		Thread t1 = new Thread(new MyThread());
		t1.setName("First Thread");
		
		Thread t2 = new Thread(new MyThread());
		t2.setName("Second Thread");
		
		Thread t3 = new Thread(new MyThread());
		t3.setName("Third Thread");
		
		t1.start();
		t2.start();
		t3.start();
		

	}

}
