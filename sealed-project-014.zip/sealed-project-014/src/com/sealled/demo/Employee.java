package com.sealled.demo;

public sealed abstract class Employee 
	permits Developer, Tester, Manager {
	
	protected String name;
    protected double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void displayEmployee() {
        System.out.println("Name   : " + name);
        System.out.println("Salary : " + salary);
    }

    public abstract void work();

	
}
