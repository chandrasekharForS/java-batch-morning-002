package com.oops.demo;

public class BankAccount {
	private String accountId;
	private String accountyName;
	private double balance;
	
	private final double MINIUM_BALANCE = 5000.00;
	
	public BankAccount() {

	}

	public BankAccount(String accountId, String accountyName, double balance) {
		this.accountId = accountId;
		this.accountyName = accountyName;
		this.balance = balance;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountyName() {
		return accountyName;
	}

	public void setAccountyName(String accountyName) {
		this.accountyName = accountyName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	// business methods
	
	//1. deposit
	public void deposit(double amount){
		balance = balance + amount;
	}
	
	//2. withdrawal
	
	public boolean withdraw(double amount) {
		if(balance - MINIUM_BALANCE >= amount) {
			balance = balance - amount;
			return true;
		}
		else {
			return false;
		}
	}
	

	@Override
	public String toString() {
		return "BankAccount [accountId=" + accountId + ", accountyName=" + accountyName + ", balance=" + balance + "]";
	}
}
