package com.arrays.demo;

import java.util.Scanner;

public class Array003 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numbers: ");
		int nums[] = new int[5];
		
		for(int i = 0; i < nums.length; i++) {
			nums[i] = scan.nextInt();
		}
		
		System.out.println("Enter a number to find: ");
		int f = scan.nextInt();
		
		boolean isFound = false;
		
		for(int i = 0; i < nums.length; i++) {
			if(f == nums[i]) {
				System.out.println("Found.");
				isFound = true;
				break;
			}
		}
		
		if(isFound == false) {
			System.out.println("Not found.");
		}
		
		scan.close();

	}

}
