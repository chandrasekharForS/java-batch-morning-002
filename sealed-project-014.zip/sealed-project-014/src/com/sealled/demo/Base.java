package com.sealled.demo;

public class Base {

}
