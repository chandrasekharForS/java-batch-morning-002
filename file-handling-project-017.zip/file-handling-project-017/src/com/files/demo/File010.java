package com.files.demo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class File010 {

	public static void main(String[] args) {
		try(BufferedWriter writer = new BufferedWriter(new FileWriter("products.txt", true))) {
			
			writer.write("Tablet");
			writer.newLine();
			
			writer.write("Smartwatch");
			writer.newLine();
			
			writer.write("Charger");
			writer.newLine();
			
			writer.write("Sunglasses");
			writer.newLine();
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
