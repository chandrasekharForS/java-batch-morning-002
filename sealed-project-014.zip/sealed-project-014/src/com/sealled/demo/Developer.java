package com.sealled.demo;

public final class Developer extends Employee{

	public Developer(String name, double salary) {
		super(name, salary);
	}

	@Override
	public void work() {
		System.out.println(name + " is developing Java applications.");
	}

}
