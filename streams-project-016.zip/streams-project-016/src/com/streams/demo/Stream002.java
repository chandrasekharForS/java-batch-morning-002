package com.streams.demo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Stream002 {

	public static void main(String[] args) {
		// filter
		/*List<Integer> numbers = Arrays.asList(10,15,20,25,30);

		numbers.stream()
		       .filter(n -> n % 2 == 0)
		       .forEach(System.out::println);
		*/
		
		// map
		
		/*List<String> names = Arrays.asList("java","python","react");

		names.stream()
		     .map(String::toUpperCase)
		     .forEach(System.out::println);
		*/
		
		// sorted
		/*List<Integer> list = Arrays.asList(8,2,6,4,1);

		list.stream()
		    .sorted()
		    .forEach(System.out::println);
		System.out.println("=============\n");
		list.stream()
	    	.sorted(Comparator.reverseOrder())
	    	.forEach(System.out::println);
		*/
		
		// distinct
		/*List<Integer> list = Arrays.asList(1,2,2,3,4,4,5);

		list.stream()
		    .distinct()
		    .forEach(System.out::println);
		*/
		
		// skip
		/*List<Integer> list = Arrays.asList(10,20,30,40,50);

		list.stream()
		    .skip(2)
		    .forEach(System.out::println);
		*/
		
		// collect
		List<Integer> even =
			    List.of(1,2,3,4,5,6)
			        .stream()
			        .filter(n -> n % 2 == 0)
			        .toList();

			System.out.println(even);

		
		
		
	}

}
