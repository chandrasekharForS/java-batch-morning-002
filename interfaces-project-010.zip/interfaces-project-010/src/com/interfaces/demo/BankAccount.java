package com.interfaces.demo;

public interface BankAccount {
	public final double MIN_BALANCE = 10000.00;
	
	double getBalance();
	void deposit(double amount);
	boolean withdraw(double amount);
}
