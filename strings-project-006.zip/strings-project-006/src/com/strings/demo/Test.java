/*
Develop a Java application named FriendsDirectory that manages and sorts the names of 100 friends.

The application should:
Store exactly 100 names in a String[].
Use a service to get the names from internet
Validate that no name is empty.
Remove leading and trailing spaces using trim().
Ignore duplicate names while displaying the final sorted list.
Sort names alphabetically without using any built-in sorting methods.
Use the Bubble Sort algorithm and compareToIgnoreCase().
Display:
Original list
Sorted list
Number of duplicate names found
Total unique names
Organize the code using methods.
Handle invalid user input gracefully.
Explain the algorithm with its time complexity (O(n²)) and space complexity (O(1)).
*/
package com.strings.demo;

class FriendsDirectory {
	private String[] names;
	private int uniqueCount;
	private int duplicateCount;

	public FriendsDirectory() {
		names = new String[100];
		uniqueCount = 0;
		duplicateCount = 0;
	}

	public void addName(String name) {
		if (name == null || name.trim().isEmpty()) {
			System.out.println("Invalid name. Please enter a non-empty name.");
			return;
		}
		name = name.trim();
		for (int i = 0; i < uniqueCount; i++) {
			if (names[i].equalsIgnoreCase(name)) {
				duplicateCount++;
				return;
			}
		}
		if (uniqueCount < names.length) {
			names[uniqueCount++] = name;
		} else {
			System.out.println("Cannot add more names. Directory is full.");
		}
	}

	public void sortNames() {
		for (int i = 0; i < uniqueCount - 1; i++) {
			for (int j = 0; j < uniqueCount - i - 1; j++) {
				if (names[j].compareToIgnoreCase(names[j + 1]) > 0) {
					String temp = names[j];
					names[j] = names[j + 1];
					names[j + 1] = temp;
				}
			}
		}
	}

	public void displayNames() {
		System.out.println("Original List:");
		for (int i = 0; i < uniqueCount; i++) {
			System.out.println(names[i]);
		}
		System.out.println("\nSorted List:");
		sortNames();
		for (int i = 0; i < uniqueCount; i++) {
			System.out.println(names[i]);
		}
		System.out.println("\nNumber of duplicate names found: " + duplicateCount);
		System.out.println("Total unique names: " + uniqueCount);
	}
}

public class Test {

	public static void main(String[] args) {
		FriendsDirectory directory = new FriendsDirectory();
		//array of names to add
		directory.addName("Alice");
		directory.addName("Bob");
		directory.addName("Charlie");
		directory.addName("alice"); // duplicate
		directory.addName("  David  "); // leading and trailing spaces
		directory.addName(""); // invalid name
		directory.addName("Eve");
		
	}
}
