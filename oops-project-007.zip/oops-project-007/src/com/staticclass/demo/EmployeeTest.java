package com.staticclass.demo;

public class EmployeeTest {

	public static void main(String[] args) {
        Employee emp1 = new Employee("Ravi", 50000);
        Employee emp2 = new Employee("Anita", 65000);
        Employee emp3 = new Employee("John", 70000);

        System.out.println(emp1);
        System.out.println(emp2);
        System.out.println(emp3);


	}

}
