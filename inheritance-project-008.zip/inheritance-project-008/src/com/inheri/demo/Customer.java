package com.inheri.demo;

public class Customer extends Person {
	private double billAmount;

	public Customer() {
		super();
	}

	public Customer(int id, String name, String address, double billAount) {
		super(id, name, address);
		
		this.billAmount = billAount;
	}

	public double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}

	@Override
	public String toString() {
		return super.toString() + ", Bill Amount=" + billAmount;
	}
}
