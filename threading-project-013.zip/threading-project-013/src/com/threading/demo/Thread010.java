package com.threading.demo;

class MyDaemonThread extends Thread {
    public void run() {
        while (true) {
        	if(Thread.currentThread().isDaemon()) {
        		System.out.println("Daemon thread is running...\n\n\n");
        	}
        	else {
        		System.out.println("Normal thread is running...");
        	}
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Thread010 {
    public static void main(String[] args) {
        MyDaemonThread dt = new MyDaemonThread();
        dt.setDaemon(true);      // Make it a daemon thread
        
        MyDaemonThread t1 = new MyDaemonThread();
        
        dt.start();
        t1.start();

        System.out.println("Main thread starts...");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Main thread ends.");
    }
}
