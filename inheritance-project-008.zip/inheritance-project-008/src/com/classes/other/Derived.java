package com.classes.other;

import com.classes.publicc.Base;

public class Derived extends Base {
	public void Test() {
		//privA = 111;
		protA = 222; // if you inherit, all the protected members of the base class becomes public in derived class.
		pubA = 333;
		//defA = 444; // we cant access default members in another package
	}
}
