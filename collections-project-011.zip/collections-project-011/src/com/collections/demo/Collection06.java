package com.collections.demo;

import java.util.ArrayList;
import java.util.List;

public class Collection06 {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<Product> ();
		
		products.add(new Product(101L, "Pen", 15.5));
		products.add(new Product(102L, "Pencil", 10.0));
		products.add(new Product(103L, "Notebook", 55.0));
		products.add(new Product(104L, "Eraser", 5.5));
		products.add(new Product(105L, "Marker", 25.0));
		products.add(new Product(106L, "Stapler", 75.0));
		products.add(new Product(107L, "File", 45.5));
		products.add(new Product(108L, "Calculator", 350.0));
		products.add(new Product(109L, "Keyboard", 850.0));
		products.add(new Product(110L, "Mouse", 550.0));
		
		double total_price = 0.0;
		
		for(Product product:products) {
			System.out.println(product);
			total_price = total_price + product.getPrice();
		}
		
		System.out.println("\n\nTotal Price: " + total_price);
	}

}
