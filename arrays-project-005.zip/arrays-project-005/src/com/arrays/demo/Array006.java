package com.arrays.demo;

import java.util.Scanner;

public class Array006 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your friend names: ");
		String names[] = new String[3];
		
		for(int i = 0; i<names.length; i++) {
			names[i] = scanner.next();
			
		}
		
		System.out.println("Before Sorting: \n");
		for(int i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
		
		
		for(int i = 0; i <names.length; i++) {
			for(int j = i + 1; j < names.length; j++) {
				if(names[i].compareTo(names[j]) > 0) {
					String temp = names[i];
					names[i] = names[j];
					names[j] = temp;
				}
			}
		}
		
		
		System.out.println("\nAfter Sorting: \n");
		for(int i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
		scanner.close();

	}

}
