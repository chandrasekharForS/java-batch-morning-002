package com.types.demo;

public class TestAnimal {

	public static void main(String[] args) {
		Animal a1 = new Animal();
		a1.eat();
		//a1.bark();
		
		Dog d1 = new Dog();
		d1.eat();
		d1.bark();
		

	}

}
