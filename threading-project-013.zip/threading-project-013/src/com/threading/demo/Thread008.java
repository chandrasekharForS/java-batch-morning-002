package com.threading.demo;

public class Thread008 {
	public static void main(String[] args) {
        SharedData data = new SharedData();
        
        new Producer(data).start();
        new Consumer(data).start();
        
        
        /*Producer p1 = new Producer(data);
        Consumer c1 = new Consumer(data);
        
        p1.start();
        c1.start();
        */
	}
}
