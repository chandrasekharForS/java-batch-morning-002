package com.collections.demo;

import java.util.ArrayList;

public class Collection03 {

	public static void main(String[] args) {
		//ArrayList<int> list = new ArrayList<int>();

		ArrayList<Integer> list = new ArrayList<Integer>();
		
		list.add(11);
		list.add(12);
		list.add(13);
		list.add(14);
		list.add(15);
		
		list.add(16);
		
		int sum = 0;
		
		for(Integer num:list)
			sum = sum + num;
		
		System.out.println("Sum: " + sum);

	}

}
