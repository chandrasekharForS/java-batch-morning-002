package com.lambda.demo;

@FunctionalInterface
interface Adder{
	int add(int n1, int n2);
}

public class Lambda003 {

	public static void main(String[] args) {
		
		/*Adder result = new Adder() {

			@Override
			public int add(int n1, int n2) {
				return n1 + n2;
			}
			
		};
		System.out.println(result.add(5, 8));
		*/
		
		
		Adder result = (n1, n2) -> n1 + n2;
		
		System.out.println(result.add(5, 8));
		
		
	}

}
