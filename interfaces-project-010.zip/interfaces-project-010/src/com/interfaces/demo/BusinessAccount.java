package com.interfaces.demo;

public class BusinessAccount implements BankAccount {
	private double balance;

	public BusinessAccount(double balance) {
		super();
		// TODO Auto-generated constructor stub
		this.balance = balance;
	}

	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}

	@Override
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		// if you deposit more than 25 lakhs , then you will get 1 %
		
		if(amount >= 2500000) {
			balance = balance + amount + 0.01 * amount;
		}
		else
			balance = balance + amount;
		
	}

	@Override
	public boolean withdraw(double amount) {
		// TODO Auto-generated method stub
		if(balance >= amount - 25000) {
			balance = balance - amount;
			return true;
		}
		else
			return false;
	}

}
