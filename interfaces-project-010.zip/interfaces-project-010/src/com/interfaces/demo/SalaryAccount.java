package com.interfaces.demo;

public class SalaryAccount implements BankAccount {
	private double balance;
	
	public SalaryAccount(double balance) {
		super();
		this.balance = balance;
	}

	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}

	@Override
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		
		balance = balance + amount;
		
	}

	@Override
	public boolean withdraw(double amount) {
		// TODO Auto-generated method stub
		if(balance >= amount) {
			balance = balance - amount;
			return true;
		}
		else
			return false;
	}

}
