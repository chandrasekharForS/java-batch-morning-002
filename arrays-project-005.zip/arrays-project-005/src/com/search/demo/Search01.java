package com.search.demo;

import java.util.Scanner;

public class Search01 {
	// 1. Leaner search
	public static int search(int []arr, int key) {
		
		for(int i = 0; i < arr.length; i++) {
			if(key == arr[i]) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numbers: ");
		int nums[] = new int[5];
		
		for(int i = 0; i < nums.length; i++) {
			nums[i] = scan.nextInt();
		}
		
		System.out.println("Enter a number to find: ");
		int f = scan.nextInt();
		
		int index = search(nums, f);
		
		if(index != -1) {
			System.out.println(f + " is found at the index " + index);
		}
		else {
			System.out.println(f + " is not found.");
		}
		
		scan.close();

	}

}
