package com.sealled.demo;

public sealed class Manager extends Employee
		permits ProjectManager{

	public Manager(String name, double salary) {
		super(name, salary);
	}

	@Override
	public void work() {
		System.out.println(name + " is managing the team.");
	}

}
