package com.latest.demo;

public interface Bank {

    // Abstract method
    void withdraw(double amount);

    // Default method
    default void deposit(double amount) {
        validateAmount(amount);
        System.out.println("Deposited: " + amount);
    }

    // Static method
    static void bankInfo() {
        System.out.println("This is a bank interface");
    }

    // Private method
    private void validateAmount(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid amount");
        }
    }
}

