package com.sealled.demo;

public final class Suv extends Car {

}
