package com.exceptions.demo;

public class Exception002 {

	public static void main(String[] args) {
		String name = new String("Anish");
		
		try {
			System.out.println(name.length());
		}
		catch(NullPointerException ex) {
			System.out.println(ex.getMessage());
		}
		System.out.println("End of the program");
	}

}
