package com.threading.demo;

public class SharedData {
    private int number;
    private boolean hasValue = false;

    public synchronized void produce(int value) {
        while (hasValue) {
            try { 
            	wait(); 
			} 
			catch (InterruptedException e) {
			
			}
        }

        this.number = value;
        hasValue = true;
        System.out.println("Produced: " + value);
        notify(); // Notify the waiting consumer
    }

    public synchronized void consume() {
        while (!hasValue) {
            try { wait(); } catch (InterruptedException e) {}
        }
        System.out.println("Consumed: " + number);
        hasValue = false;
        notify(); // Notify the waiting producer
    }
}

