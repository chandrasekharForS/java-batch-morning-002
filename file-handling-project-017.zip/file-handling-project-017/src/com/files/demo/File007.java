package com.files.demo;

import java.util.Scanner;

public class File007 {

	public static void main(String[] args) {
		String cities = "Bangalore,Mumbai,Kolkatta,Tirupathi,Vijayawada";
		//String cities = "Bangalore+Mumbai+Kolkatta+Tirupathi+Vijayawada";
		
		Scanner scanner = new Scanner(cities);
		//scanner.useDelimiter("\\+");
		scanner.useDelimiter(",");
		
		while(scanner.hasNext()) {
			System.out.println(scanner.next());
		}
		
		scanner.close();
	}

}
