package com.collections.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Collection07 {

	public static void main(String[] args) {
		/*List<String> cities = new ArrayList<String>();
		
		cities.add("Bangalore");
		cities.add("Mumbai");
		cities.add("Delhi");
		
		System.out.println(cities.get(1));
		*/
		
		/*Set<String> cities = new HashSet<String>();
		cities.add("Bangalore");
		cities.add("Mumbai");
		cities.add("Delhi");
		
		System.out.println(cities);
		*/
		
		/*Map<String, Integer> departmentWiseEmployeeCount = 
				new HashMap<String, Integer>();
		
		departmentWiseEmployeeCount.put("IT", 15);
		departmentWiseEmployeeCount.put("HR", 12);
		departmentWiseEmployeeCount.put("Production", 1200);
		departmentWiseEmployeeCount.put("IT", 12);
		
		for(String key : departmentWiseEmployeeCount.keySet()) {
			System.out.println(key + "=>" + departmentWiseEmployeeCount.get(key));
		}
		
		for(Integer value : departmentWiseEmployeeCount.values()) {
			System.out.println(value);
		}*/
		
		/*Set<String> cities = new TreeSet<String>();
		cities.add("Bangalore");
		cities.add("Mumbai");
		cities.add("Delhi");
		
		System.out.println(cities);
		*/
		
		/*Map<String, Integer> departmentWiseEmployeeCount = 
				new TreeMap<String, Integer>();
		
		departmentWiseEmployeeCount.put("IT", 15);
		departmentWiseEmployeeCount.put("HR", 12);
		departmentWiseEmployeeCount.put("Production", 1200);
		departmentWiseEmployeeCount.put("IT", 12);
		
		for(String key : departmentWiseEmployeeCount.keySet()) {
			System.out.println(key + "=>" + departmentWiseEmployeeCount.get(key));
		}*/
		
		Queue<String> queue = new LinkedList<String>();
		
		queue.offer("First");
		queue.offer("Second");
		queue.offer("Third");
		
		/*for(String ele:queue)
			System.out.println(ele);
		*/
		
		while(!queue.isEmpty()) {
			System.out.println(queue.poll());
		}
		
		String dear="hello";
		Integer n = 100;
		
	}

}
