package com.files.demo;

import java.io.FileInputStream;
import java.io.IOException;

public class File015 {

	public static void main(String[] args) {
		try(FileInputStream fis = new FileInputStream("products.txt")){
			byte[] buffer = new byte[1024];
			int bytesRead;
			
			while((bytesRead = fis.read(buffer))!= -1) {
				System.out.write(buffer, 0, bytesRead);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
