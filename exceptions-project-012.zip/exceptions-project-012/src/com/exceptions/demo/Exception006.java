package com.exceptions.demo;

public class Exception006 {

	public static void main(String[] args) /*throws InterruptedException*/ {
		
		/*System.out.println("Hello Dear.");
		try {
			Thread.sleep(-5000);
		}
		catch(InterruptedException ex) {
			System.out.println(ex.getMessage());
		}
		catch(IllegalArgumentException ex) {
			System.out.println(ex.getMessage());
		}
		System.out.println("Where are you?");
		*/
		
		System.out.println("Hello Dear.");
		try {
			Thread.sleep(5000);
		}
		catch(IllegalArgumentException | InterruptedException ex) {
			System.out.println(ex.getMessage());
		}
		System.out.println("Where are you?");
	}

}
