package com.threading.demo;

class MyThread04 extends Thread{
	@Override
	public void run() {
		System.out.println("Thread " + Thread.currentThread().getName() + " is running...");
	}
}
public class Thread004 {

	public static void main(String[] args) {
		MyThread04 t1 = new MyThread04();
		t1.setName("First");
		MyThread04 t2 = new MyThread04();
		t2.setName("Second");
		MyThread04 t3 = new MyThread04();
		t3.setName("Third");
		
		System.out.println(t1.getState());
		System.out.println(t2.getState());
		System.out.println(t3.getState());
		
		t1.start();
		t2.start();
		t3.start();
		
		System.out.println(t1.getState());
		System.out.println(t2.getState());
		System.out.println(t3.getState());

	}

}
