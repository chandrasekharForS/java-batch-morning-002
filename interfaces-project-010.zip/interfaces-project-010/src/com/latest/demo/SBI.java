package com.latest.demo;

class SBI implements Bank {
    @Override
    public void withdraw(double amount) {
        System.out.println("Withdrawn: " + amount);
    }
}

