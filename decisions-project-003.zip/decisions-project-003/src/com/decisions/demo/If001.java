package com.decisions.demo;

import java.util.Scanner;

public class If001 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter number1: ");
		int n1 = scan.nextInt();
		
		System.out.println("Enter number2: ");
		int n2 = scan.nextInt();
		
		//1. if
		/*if(n1 > n2) {
			System.out.println("n1 is big.");
		}*/
		
		//2.if else
		/*if(n1 > n2) {
			System.out.println("n1 is big.");
		}
		else {
			System.out.println("n2 is big.");
		}*/
		
		//3. if else if
		if(n1 > n2) {
			System.out.println("n1 is big.");
		}
		else if(n2 > n1) {
			System.out.println("n2 is big.");
		}
		else {
			System.out.println("Both are same.");
		}
		
	}
}
