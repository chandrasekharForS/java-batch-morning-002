import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the radius: ");
		int radius = scan.nextInt();
		
		//double area = 3.14 * radius * radius;
		
		//double area = 22/7 * radius * radius;
		
		//double area = 22.0/7 * radius * radius;
		
		//double area = 22/7.0 * radius * radius;
		
		double area = Math.PI * radius * radius;
		
		System.out.println("Area: " + area);

	}

}
