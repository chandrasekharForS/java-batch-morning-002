package com.threading.demo;

public class Thread006 {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount();

        // Create multiple threads accessing the same account
        WithdrawThread t1 = new WithdrawThread(sharedAccount, "Alice", 700);
        WithdrawThread t2 = new WithdrawThread(sharedAccount, "Bob", 400);
        WithdrawThread t3 = new WithdrawThread(sharedAccount, "Charlie", 300);

        /*t1.setPriority(10);
        t2.setPriority(9);
        t3.setPriority(8);
        */
        
        // Start threads
        t1.start();
        t2.start();
        t3.start();
    }
}

