package com.latest.demo;

public class TestVehicle {

	public static void main(String[] args) {
		Vehicle v = new Car();
		v.start();
		
		v = new MotorCycle();
		v.start();

	}

}
