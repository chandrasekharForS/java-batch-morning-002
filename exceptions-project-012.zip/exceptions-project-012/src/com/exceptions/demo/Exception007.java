package com.exceptions.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Exception007 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        
        Iterator<String> iterator = list.iterator();
        
        try {
            iterator.remove(); // This will throw IllegalStateException
        } catch (IllegalStateException e) {
            System.out.println("Caught IllegalStateException: " + e.getMessage());
        }
        
        list.remove(0);
        System.out.println(list);


	}

}
