package com.lambda.demo;

import java.util.function.Predicate;

public class Lambda005 {

	public static void main(String[] args) {
		/*String st = "Hello";
		System.out.println(st.isEmpty());
		*/
		Predicate<String> isEmpty = s -> s.isEmpty();
		
		System.out.println(isEmpty.test("Hello"));
		System.out.println(isEmpty.test(""));
		
	}

}
