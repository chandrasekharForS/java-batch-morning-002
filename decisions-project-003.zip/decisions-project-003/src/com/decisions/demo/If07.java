package com.decisions.demo;

import java.util.Scanner;

public class If07 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a character: ");
		char ch = scan.next().charAt(0);
		//if((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) {
		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
			switch(ch) {
				case 'A':
				case 'E':
				case 'I':
				case 'O':
				case 'U':
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':System.out.println("Vowel");break;
				default:System.out.println("Consonant.");
			}
		}
		else {
			System.out.println("Invalid input.");
		}
	}
}
