package com.decisions.demo;

import java.util.Scanner;

public class If02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter number: ");
		int num = scan.nextInt();
		
		if(num > 0) {
			if(num % 2 == 0) {
				System.out.println("Even.");
			}
			else {
				System.out.println("Odd.");
			}
		}
		else {
			System.out.println("Wrong input.");
		}
	}

}
