package com.abstractt.demo;

public class Rectangle extends Shape{
	private double length;
	private double width;
	
	public Rectangle(double length, double width) {
		super();
		this.length = length;
		this.width = width;
	}
	
	@Override
	public double findArea() {
		return length * width;
	}
	
	@Override
	public double findCircumference() {
		return 2 * (length + width);
	}
	
	

}
