package com.threading.demo;

public class Thread005 {

    public static void main(String[] args) {

        Restaurant restaurant = new Restaurant();

        Chef chef = new Chef(restaurant);
        
        DeliveryBoy delivery = new DeliveryBoy(restaurant);

        // NEW
        System.out.println("Chef State : " + chef.getState());
        System.out.println("Delivery State : " + delivery.getState());

        chef.start();
        delivery.start();

        // Allow both threads to reach WAITING
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Chef State : " + chef.getState());
        System.out.println("Delivery State : " + delivery.getState());

        // Customer places order
        restaurant.placeOrder();

        // Allow Chef to start cooking
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Chef State : " + chef.getState());
        System.out.println("Delivery State : " + delivery.getState());

       try {
            chef.join();
            delivery.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Chef State : " + chef.getState());
        System.out.println("Delivery State : " + delivery.getState());
    	
    }
}
