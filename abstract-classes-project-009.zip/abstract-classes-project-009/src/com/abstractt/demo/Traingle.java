package com.abstractt.demo;

public abstract class Traingle extends Shape {
	private double s1, s2, s3;
	
	public Traingle(double s1, double s2, double s3) {
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
	}

	@Override
	public double findArea() {
		// TODO Auto-generated method stub
		return 100.00;
	}

}
