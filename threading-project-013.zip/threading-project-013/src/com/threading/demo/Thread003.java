package com.threading.demo;

class MyThread03 extends Thread{
	@Override
	public void run() {
		for(int i = 1; i <= 5; i++) {
			System.out.println(Thread.currentThread().getName() + ": " + i);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public class Thread003 {

	public static void main(String[] args) {
		MyThread03 t1 = new MyThread03();
		t1.setName("First Thread");
		
		MyThread03 t2 = new MyThread03();
		t2.setName("Second Thread");
		
		MyThread03 t3 = new MyThread03();
		t3.setName("Third Thread");
		
		t1.start();
		t2.start();
		t3.start();

	}

}
