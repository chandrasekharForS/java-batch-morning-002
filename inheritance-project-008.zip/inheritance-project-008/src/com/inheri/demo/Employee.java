package com.inheri.demo;

public class Employee extends Person {
	private double salary;
	
	public Employee() {
		super();
	}

	public Employee(int id, String name, String address, double salary) {
		super(id, name, address);
		
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return super.toString() + ", salary=" + salary;
	}	
}
