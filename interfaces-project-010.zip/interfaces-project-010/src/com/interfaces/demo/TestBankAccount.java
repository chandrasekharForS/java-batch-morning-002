package com.interfaces.demo;

public class TestBankAccount {

	public static void main(String[] args) {
		//BankAccount account = new BankAccount();
		BankAccount account;
		
		account = new SavingsAccount(10000);
		System.out.println("Balance: " + account.getBalance());
		
		account.deposit(7000);
		System.out.println("Balance after deposit: " + account.getBalance());
		
		if(account.withdraw(17000)) {
			System.out.println("Success.");
		}
		else {
			System.out.println("Failed");
		}
		
		System.out.println("Balance after withdrawl: " + account.getBalance());
		
		
		account = new BusinessAccount(25000);
		System.out.println("Balance: " + account.getBalance());
		
		account.deposit(3000000.00);
		System.out.println("Balance: " + account.getBalance());
	
		if(account.withdraw(3081000.00)) {
			System.out.println("Success.");
		}
		else {
			System.out.println("Failed.");
		}
		System.out.println("Balance: " + account.getBalance());
	}
	
	

}
