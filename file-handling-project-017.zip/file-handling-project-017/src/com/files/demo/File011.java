package com.files.demo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class File011 {

	public static void main(String[] args) {
		try(PrintWriter writer = new PrintWriter(new FileWriter("messages.txt"))) {
			writer.write("Hello Dear!");
			writer.write("\nWhere are you?");
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
