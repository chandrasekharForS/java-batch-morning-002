package com.oops.demo;

public class BankAccountTest {

	public static void main(String[] args) {
		
		BankAccount accounts[] = new BankAccount[5];
		
		accounts[0] = new BankAccount("123456789", "Anish Kumar", 25000.00);
		accounts[1] = new BankAccount("223456789", "Divya", 35000.00);
		accounts[2] = new BankAccount("323456789", "Rajesh Kumar", 5000.00);
		accounts[3] = new BankAccount("423456789", "Priya", 55000.00);
		accounts[4] = new BankAccount("523456789", "Suresh", 3000.00);
		
		
		
		/*double total = accounts[0].getBalance() + accounts[1].getBalance() + 
				accounts[2].getBalance() + accounts[3].getBalance() 
				+ accounts[4].getBalance();
		*/
		
		double total = 0.0;
		for(BankAccount account:accounts) {
			total = total + account.getBalance();
		}
		
		/*for(int i = 0; i < accounts.length; i++) {
			total = total + accounts[i].getBalance();
		}*/
		
		System.out.println("Total: " + total);
		
		/*BankAccount acc1 = new BankAccount("123456789", "Anish Kumar", 15000.00);
	
		BankAccount acc2 = new BankAccount("223456789", "Divya", 25000.00);
		
		System.out.println(acc1);
		System.out.println(acc2);
		
		
		acc1.deposit(7500.00);
		System.out.println("Balance of acc1 after depositing: " + acc1.getBalance());
		
		if(acc1.withdraw(17500.00) == true) {
			System.out.println("Withdrawal is Success.");
		}
		else {
			System.out.println("Withdrawal is Failure.");
		}
		System.out.println("Balance of acc1 after withdrawal: " + acc1.getBalance());
		*/
		
		

	}

}
