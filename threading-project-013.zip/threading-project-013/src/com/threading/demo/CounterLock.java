package com.threading.demo;

import java.util.concurrent.locks.ReentrantLock;



public class CounterLock {
    private int count = 0;
    private final ReentrantLock lock = new ReentrantLock();

    public void increment() {
        lock.lock();
        try {
            count++;
        } 
        finally {
            lock.unlock(); // must unlock manually
        }
    }

    public int getCount() {
        return count;
    }

    public static void main(String[] args) throws InterruptedException {
        CounterLock counter = new CounterLock();

        Runnable task = () -> {
            for (int i = 0; i < 1000; i++) {
                counter.increment();
            }
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        // Expected: 2 threads * 1000 iterations = 2000
        System.out.println("Final count: " + counter.getCount());
    }
}

