package com.sealled.demo;

public non-sealed class Bike extends Vehicle {

}
