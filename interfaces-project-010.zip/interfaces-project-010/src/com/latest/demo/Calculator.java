package com.latest.demo;

public interface Calculator {
	static int add(int n1, int n2) {
		return n1 + n2;
	}
	
	static int subtract(int n1, int n2) {
		return n1 - n2;
	}
	
	static int multiply(int n1, int n2) {
		return n1 * n2;
	}
	
	static double divide(int n1, int n2) {
		return (double)n1 / n2;
	}
}
