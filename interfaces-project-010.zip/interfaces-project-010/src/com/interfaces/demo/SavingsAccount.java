package com.interfaces.demo;

public class SavingsAccount implements BankAccount {
	private double balance;
	
	
	
	
	public SavingsAccount(double balance) {
		this.balance = balance;	
	}
	
	@Override
	public double getBalance() {
		return balance;
	}
	
	@Override
	public void deposit(double amount) {
		balance = balance + amount;
	}
	
	@Override
	public boolean withdraw(double amount) {
		if(balance >= amount + MIN_BALANCE ) {
			balance = balance - amount;
			return true;
		}
		else
			return false;
	}
}
