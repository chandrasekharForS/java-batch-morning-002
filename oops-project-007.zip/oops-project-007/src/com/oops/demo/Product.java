package com.oops.demo;

public class Product{
	private int productId;
	private String productName;
	private double price;
	private int stock;
	
	public void createProduct(int id, String name, double prc, int stk) { // formal parameters
		productId = id;
		productName = name;
		price = prc;
		stock = stk;
	}
	
	public void showProduct() {
		System.out.println("ID: " + productId);
		System.out.println("Name: " + productName);
		System.out.println("Price: " + price);
		System.out.println("Stock: " + stock);
	}
}
