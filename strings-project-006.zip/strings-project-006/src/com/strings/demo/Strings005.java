package com.strings.demo;

public class Strings005 {

	public static void main(String[] args) {
		StringBuilder str = new StringBuilder("Java");
		System.out.println(str);
		
		str.append(" is a programming language.");
		System.out.println(str);
		
		str.insert(9, " OOPS");
		System.out.println(str);

	}

}
