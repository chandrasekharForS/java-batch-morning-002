package com.staticclass.demo;

public class Employee {
    // Static Data Members
    private static String companyName;
    private static String companyLocation;
    private static int nextEmployeeId;
    
    // Instance Data Members
    private int employeeId;
    private String employeeName;
    private double salary;
    
    static {
    	companyName = "T.C.S";
    	companyLocation = "Bangalore";
    	nextEmployeeId=11;
    }
    
 // Constructor
    public Employee(String employeeName, double salary) {
        this.employeeId = EmployeeIdGenerator.generateEmployeeId();
        this.employeeName = employeeName;
        this.salary = salary;
    }
    
    // Static Nested Class
    public static class EmployeeIdGenerator {

        public static int generateEmployeeId() {
            return nextEmployeeId++;
        }
    } 
    
    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", employeeName='" + employeeName + '\'' +
                ", salary=" + salary +
                ", companyName='" + companyName + '\'' +
                ", companyLocation='" + companyLocation + '\'' +
                '}';
    }

}
