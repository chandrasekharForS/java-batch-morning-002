import java.util.Scanner;

public class Square1 {

	public static void main(String[] args) {
		int n1, r;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a number: ");
		n1 = scan.nextInt();
		
		r = n1 * n1;
		
		System.out.println("Result: " + r);

	}
}
