package com.sealled.demo;

public sealed class Car extends Vehicle permits Sedan, Suv {

}
