package com.abstractt.demo;

public class Circle extends Shape {
	
	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	@Override
	public double findArea() {
		return 3.14 * radius * radius;
	}
	
	@Override
	public double findCircumference() {
		return 2 * 3.14 * radius;
	}

}
