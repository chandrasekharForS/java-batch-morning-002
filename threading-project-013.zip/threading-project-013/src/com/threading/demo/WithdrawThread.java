package com.threading.demo;

//WithdrawThread.java
public class WithdrawThread extends Thread {
	 private BankAccount account;
	 private String name;
	 private double amount;
	
	 public WithdrawThread(BankAccount account, String name, double amount) {
	     this.account = account;
	     this.name = name;
	     this.amount = amount;
	 }
		
	 @Override
	 public void run() {
	     account.withdraw(name, amount);
	 }
}

