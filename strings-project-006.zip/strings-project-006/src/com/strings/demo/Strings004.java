package com.strings.demo;

public class Strings004 {

	public static void main(String[] args) {
		StringBuffer str = new StringBuffer("Java");
		System.out.println(str);
		
		str.append(" is a programming lanaguage.");
		System.out.println(str);
		
		str.insert(9, " OOPS");
		System.out.println(str);
		
		str.replace(0, 4, "Python");
		System.out.println(str);
		
		System.out.println(str.length());
		
		str.delete(29, 39);
		System.out.println(str);
		
		str.deleteCharAt(17);
		System.out.println(str);
		
		
		str = new StringBuffer("Hello");
		System.out.println(str);
		//System.out.println(str.reverse());
		
		System.out.println("Capacity: " + str.capacity());
		
		str.setCharAt(1, 'E');
		System.out.println(str);
		
		
		
		
		

	}

}
