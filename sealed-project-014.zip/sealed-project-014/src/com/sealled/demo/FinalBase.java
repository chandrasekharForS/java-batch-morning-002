package com.sealled.demo;

public final class FinalBase {

}
