package com.sealled.demo;

public final class ProjectManager extends Manager {
	public ProjectManager(String name, double salary) {
        super(name, salary);
    }

    @Override
    public void work() {
        System.out.println(name + " is planning project schedules.");
    }
}
