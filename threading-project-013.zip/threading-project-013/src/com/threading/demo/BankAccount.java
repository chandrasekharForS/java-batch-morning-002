package com.threading.demo;

//BankAccount.java
public class BankAccount {
	 private double balance = 1000;
	
	 // Synchronized method to withdraw money
	 public synchronized void withdraw(String name, double amount) {
	     System.out.println(name + " is trying to withdraw $" + amount);
	     
	     if (balance >= amount) {
	         System.out.println(name + " is allowed to withdraw.");
	         try {
	             Thread.sleep(100); // Simulate processing time
	         } catch (InterruptedException e) {
	             e.printStackTrace();
	         }
	         balance -= amount;
	         System.out.println(name + " has completed the withdrawal. Remaining balance: $" + balance);
	     } else {
	         System.out.println("Sorry, not enough balance for " + name + ". Remaining: $" + balance);
	     }
	 }
	
	 public double getBalance() {
	     return balance;
	 }
}
