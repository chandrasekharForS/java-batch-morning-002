package com.exceptions.demo;

public class Exception008 {

	public static void main(String[] args) {
		String str = "12m345";
		
		try {
			int num = Integer.parseInt(str);
			
			System.out.println(num * 2);
		}
		catch(NumberFormatException ex) {
			System.out.println(ex.getMessage());
		}

	}

}
