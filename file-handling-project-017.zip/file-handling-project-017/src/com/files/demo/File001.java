package com.files.demo;

import java.io.File;
import java.io.IOException;

public class File001 {

	public static void main(String[] args) {
		File file = new File("marks.txt");
		
		try {
			file.createNewFile();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("File created.");

	}

}
