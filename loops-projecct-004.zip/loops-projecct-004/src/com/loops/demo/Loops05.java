package com.loops.demo;

import java.util.Scanner;

public class Loops05 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the number: ");
		int num = scan.nextInt();
		
		int rev = 0;
		while(num > 0) {
			int rem = num % 10;
			
			rev = rev * 10 + rem;
			
			num = num / 10;
		}
		
		System.out.println("Reverse: " + rev);

	}

}
