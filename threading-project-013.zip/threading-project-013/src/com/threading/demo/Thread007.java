package com.threading.demo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Thread007 {
    public static void main(String[] args) {
        // Create a thread pool of 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Submit 6 jobs
        for (int i = 1; i <= 6; i++) {
            PrintJob job = new PrintJob("Task " + i);
            executor.submit(job);
        }

        executor.shutdown(); // No more tasks will be submitted
    }
}
