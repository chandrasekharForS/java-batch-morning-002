package com.latest.demo;

public class TestCalculator {

	public static void main(String[] args) {
		//Calculator c1 = new Calculator();
		
		System.out.println("Sum: " + Calculator.add(20, 10));
		System.out.println("Difference: " + Calculator.subtract(20, 10));
		System.out.println("Product: " + Calculator.multiply(20, 10));
		System.out.println("Division: " + Calculator.divide(20, 11));
		
		//System.out.println("Sum: " + ElectronicCalculator.add(20, 10));

	}

}
